
To run the program, the contents of SDL-2.dmg file must first be moves into /Library/Frameworks/. This can be done from the desktop by pressing go->go to folder->/Library/Frameworks/ and then dragging the files. This is done to dynamically link the library.

Next press the .exe file to run the program. 


